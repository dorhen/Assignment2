package bgu.spl.mics.application.passiveObjects;

import java.io.Serializable;

public class CreditCard implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	public int number;
	public int amount;

	public CreditCard(int number, int amount) {
		this.number = number;
		this.amount = amount;
	}
}
