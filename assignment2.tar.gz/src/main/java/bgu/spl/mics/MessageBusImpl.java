package bgu.spl.mics;

import java.util.HashMap;
import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;
import java.util.concurrent.ConcurrentHashMap;

/**
 * The {@link MessageBusImpl class is the implementation of the MessageBus
 * interface. Write your implementation here! Only private fields and methods
 * can be added to this class.
 */
public class MessageBusImpl implements MessageBus {

	private static MessageBusImpl instance = null;
	private Map<MicroService, Queue<Message>> microServiceQueue;
	private Map<Class<? extends Message>, Queue<MicroService>> roundRobinMap;
	private Map<Event<?>, Future<?>> futureMap;

	private MessageBusImpl() {
		microServiceQueue = new ConcurrentHashMap<MicroService, Queue<Message>>();
		roundRobinMap = new ConcurrentHashMap<Class<? extends Message>, Queue<MicroService>>();
		futureMap = new ConcurrentHashMap<Event<?>, Future<?>>();
	}

	public static MessageBusImpl getInstance() {
		if (instance == null)
			instance = new MessageBusImpl();
		return instance;
	}

	@Override
	public <T> void subscribeEvent(Class<? extends Event<T>> type, MicroService m) {
		synchronized (type) {
			if (roundRobinMap.get(type) == null)
				roundRobinMap.put(type, new LinkedList<MicroService>());
		}
		roundRobinMap.get(type).add(m);
	}

	@Override
	public void subscribeBroadcast(Class<? extends Broadcast> type, MicroService m) {
		synchronized (type) {
			if (roundRobinMap.get(type) == null)
				roundRobinMap.put(type, new LinkedList<MicroService>());
		}
		Queue<MicroService> q = roundRobinMap.get(type);
		synchronized(q) {q.add(m);}
	}

	@Override
	public <T> void complete(Event<T> e, T result) {
		Future<T> ft = (Future<T>) futureMap.get(e);
		ft.resolve(result);
	}

	@Override
	public void sendBroadcast(Broadcast b) {
		Queue<MicroService> q = roundRobinMap.get(b.getClass());
		if(q!=null) {
			synchronized(q) {
				for (MicroService m : q)
					microServiceQueue.get(m).add(b);
				synchronized(this) {notifyAll();}
			}
		}
	}

	@Override
	public <T> Future<T> sendEvent(Event<T> e) {
		Future<T> ft = new Future<T>();
		futureMap.put(e, ft);
		Queue<MicroService> msQ = roundRobinMap.get(e.getClass());
		if (msQ == null)
			return null;
		synchronized (msQ) {
			MicroService m = msQ.poll();
			if (m == null)
				return null;
			microServiceQueue.get(m).add(e);
			msQ.add(m);
			synchronized(this) {notifyAll();}
		}
		return ft;
	}

	@Override
	public void register(MicroService m) {
		Queue<Message> q = new LinkedList<Message>();
		microServiceQueue.put(m, q);
	}

	@Override
	public void unregister(MicroService m) {
		Queue<Message> q = microServiceQueue.get(m);
		for (Message e : q)
			if (e instanceof Event<?>)
				complete((Event<?>) e, null);
		for (Map.Entry<Class<? extends Message>, Queue<MicroService>> pair : roundRobinMap.entrySet()) {
			synchronized(pair.getValue())  { pair.getValue().remove(m); }
		}
	}

	@Override
	public Message awaitMessage(MicroService m) throws InterruptedException {
		Queue<Message> q = microServiceQueue.get(m);
		if (q == null)
			throw new IllegalStateException("Micro-Service was never registered");
		while (q.isEmpty())
			synchronized(this) {wait();}
		return q.remove();
	}

}

