package bgu.spl.mics.application.passiveObjects;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

public class InventoryTest {

	private Inventory inv;

	@Before
	public void setUp() throws Exception {
		inv = Inventory.getInstance();
	}

	@Test
	public void testGetInstance() {
		assertTrue(inv != null);
	}

	@Test
	public void testLoad() {
		BookInventoryInfo a = new BookInventoryInfo("Test book", 1, 50);
		BookInventoryInfo[] arr = { a };
		inv.load(arr);

	}

	@Test
	public void testTake() {
		OrderResult res = inv.take("Test book");
		assertEquals(res, OrderResult.SUCCESSFULLY_TAKEN);
		OrderResult res1 = inv.take("Test book");
		assertEquals(res1, OrderResult.NOT_IN_STOCK);

	}

	@Test
	public void testCheckAvailabiltyAndGetPrice() {
		int res = inv.checkAvailabiltyAndGetPrice("Test book");
		assertEquals(res, 50);
		int res1 = inv.checkAvailabiltyAndGetPrice("Non Existing");
		assertEquals(res1, -1);
	}

}
