package bgu.spl.mics;

public class DerievedMicroService extends MicroService {
	
	public DerievedMicroService(String s) {
		super(s);
	}

	@Override
	protected void initialize() {
		// TODO Auto-generated method stub
	}
	

}
