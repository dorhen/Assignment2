package bgu.spl.mics.application;

import bgu.spl.mics.application.passiveObjects.BookInventoryInfo;

public class InputContainer {
	public BookInventoryInfo[] initialInventory;
	public Resources[] initialResources;
	public ServicesInput services;

}
