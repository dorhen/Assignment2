package bgu.spl.mics.application;

public class Time {
	public int speed;
	public int duration;
}
