package bgu.spl.mics.application;

import bgu.spl.mics.application.passiveObjects.DeliveryVehicle;

public class Resources {
	public DeliveryVehicle[] vehicles;

}
