package bgu.spl.mics.example.messages;

public class ExampleResult {

}
