package bgu.spl.mics;

import static org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;

import bgu.spl.mics.example.messages.ExampleResult;


public class FutureTest {

	private Future<ExampleResult> ft;

	@Before
	public void setUp() throws Exception {
		ft = new Future<ExampleResult>();
	}

	@Test
	public void testGet() {
		ExampleResult r1 = new ExampleResult();
		ft.resolve(r1);
		ExampleResult result = ft.get();
		assertFalse(result == null);
		assertTrue(result != null);

	}

	@Test
	public void testResolve() {
		ExampleResult result = new ExampleResult();
		;
		ft.resolve(result);
		ExampleResult result2 = ft.get();
		assertEquals(result, result2);
	}

}
